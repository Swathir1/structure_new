#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "rss.h"

// TODO: implement these functions

Rss * createEmptyRss() {
}

Rss * createRss(const char * title, const char * link, const char * date, const char * description) {
}

void initRss(Rss *feed, const char* title, const char* link, const char* date,
               const char* description);


void printRss(const Rss * item) {
}
